""" import all the models in the folder here"""
from app.main.models.UserModel import User
from app.main.models.GameModel import Game
from app.main.models.RoleModel import Role
from app.main.models.TransactionModel import Transaction